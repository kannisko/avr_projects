package dso;

/**
 * Created by Pawel.Piotrowski on 2015-12-01.
 */
public abstract class   DsoPortId {
    public abstract String getName();
}
