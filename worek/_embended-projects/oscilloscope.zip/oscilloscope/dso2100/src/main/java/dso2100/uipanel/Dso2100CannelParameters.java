package dso2100.uipanel;

import javax.swing.*;

/**
 * Created by Pawel.Piotrowski on 2015-12-23.
 */
public class Dso2100CannelParameters {
    private JComboBox verticalSens;
    private JRadioButton DCRadioButton;
    private JRadioButton ACRadioButton;
    private JRadioButton GNDRadioButton;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
