package jnpout32;

/**
 * Created by Pawel.Piotrowski on 2015-12-23.
 */
public class VirtualIOPort {
    public  void Out32(short PortAddress, short data){

    }

    // input a value from a specified port address
    public short Inp32(short PortAddress){
        return 0xFF;
    }

}
