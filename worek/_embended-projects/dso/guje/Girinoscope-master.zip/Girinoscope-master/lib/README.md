The `quaqua.jar` for the [Quaqua Look and Feel](http://www.randelshofer.ch/quaqua/)
is optional and meant to be used on Mac OS X to achieve a better integration
(but it doesn’t hurt to have it in the classpath on other platforms).

