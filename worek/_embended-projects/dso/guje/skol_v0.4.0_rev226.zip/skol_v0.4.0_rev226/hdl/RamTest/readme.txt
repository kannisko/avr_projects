ramTest

includes TestBench to test Ram Timing. Only for simulation usage.

