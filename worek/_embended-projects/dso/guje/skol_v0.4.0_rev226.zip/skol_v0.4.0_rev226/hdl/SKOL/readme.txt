Skol_MultipleDataAquisition

Aqires Multiple Data from the ADC and stores them.
Data can be read by PC after (RS232).