lcd byte driver example

For a better state machine example on how to use the lcd driver  see -> Skol_SingleDataAquisition