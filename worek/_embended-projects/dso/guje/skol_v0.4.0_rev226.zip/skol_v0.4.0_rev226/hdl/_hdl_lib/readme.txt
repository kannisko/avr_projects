This Folder contains all used Modules.
Some Projects use Files direct from within this Folder.