/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SkolUtil;

/**
 *
 * @author sush
 */
public class messageException  extends Exception 
{

    messageException(String string) 
    {
         super(string);
    }


}