# arduino-oscilloscope

This repository contains a few materials for creating a simple oscilloscope
with arduino. Arduino oscilloscope based on Girino.
The arduino and oscilloscope applications were open source, and I only
patched them slightly for my needs.

For a detailed explanation check my blog post:
http://sangorrin.blogspot.jp/2015/06/arduino-oscilloscope.html

 -- Daniel Sangorrin
